create view user_participation(key, email, record_key, record_title, record_create_time, duration) as
SELECT u.key,
       u.email,
       r.record_key,
       r.title        AS record_title,
       r.created_date AS record_create_time,
       r.duration
FROM follow_up_service.users u
         JOIN follow_up_service.recordings r ON u.key = ANY (r.participants);

alter table user_participation
    owner to admin;

grant delete, insert, references, select, trigger, truncate, update on user_participation to gen_user;

