create view purchase_info
            (organization_name, purchase_id, courier_id, customer_id, status, courier_name, customer_name, point_a,
             point_b, price, comment, create_purchase_time, start_time, end_time, rownum)
as
WITH rankedpurchases AS (SELECT customers.organization_name,
                                purchases.purchase_id,
                                purchases.courier_id,
                                purchases.customer_id,
                                purchase_details.status,
                                purchase_details.courier_name,
                                purchase_details.customer_name,
                                purchase_details.point_a,
                                purchase_details.point_b,
                                purchase_details.price,
                                purchase_details.comment,
                                purchases.create_purchase_time,
                                purchase_details.start_time,
                                purchase_details.end_time,
                                row_number()
                                OVER (PARTITION BY purchases.purchase_id ORDER BY purchases.create_purchase_time DESC) AS rownum
                         FROM purchases
                                  JOIN customers ON purchases.customer_id = customers.customer_id
                                  LEFT JOIN purchase_details ON purchases.purchase_id = purchase_details.purchase_id)
SELECT rankedpurchases.organization_name,
       rankedpurchases.purchase_id,
       rankedpurchases.courier_id,
       rankedpurchases.customer_id,
       rankedpurchases.status,
       rankedpurchases.courier_name,
       rankedpurchases.customer_name,
       rankedpurchases.point_a,
       rankedpurchases.point_b,
       rankedpurchases.price,
       rankedpurchases.comment,
       rankedpurchases.create_purchase_time,
       rankedpurchases.start_time,
       rankedpurchases.end_time,
       rankedpurchases.rownum
FROM rankedpurchases
WHERE rankedpurchases.rownum = 1
ORDER BY rankedpurchases.create_purchase_time DESC;

alter table purchase_info
    owner to gen_user;

grant delete, insert, references, select, trigger, truncate, update on purchase_info to admin;

