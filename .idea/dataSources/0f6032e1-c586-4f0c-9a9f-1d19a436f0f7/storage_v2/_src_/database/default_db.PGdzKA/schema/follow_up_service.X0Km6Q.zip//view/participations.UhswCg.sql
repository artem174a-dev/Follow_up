create view participations (key, email, record_key, record_title, record_create_time, duration, participations) as
SELECT u.key,
       u.email,
       r.record_key,
       r.title                                       AS record_title,
       r.created_date                                AS record_create_time,
       r.duration,
       count(u.key) OVER (PARTITION BY r.record_key) AS participations
FROM follow_up_service.users u
         JOIN follow_up_service.recordings r ON u.key = ANY (r.participants)
GROUP BY u.key, u.email, r.record_key, r.title, r.created_date, r.duration;

alter table participations
    owner to admin;

grant delete, insert, references, select, trigger, truncate, update on participations to gen_user;

