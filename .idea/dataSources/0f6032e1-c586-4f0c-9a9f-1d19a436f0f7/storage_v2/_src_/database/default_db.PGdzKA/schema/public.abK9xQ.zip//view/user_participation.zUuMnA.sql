create view user_participation
            (key, email, record_key, record_title, record_create_time, duration, participants_count) as
SELECT u.key,
       u.email,
       r.record_key,
       r.title        AS record_title,
       r.created_date AS record_create_time,
       r.duration,
       count(u.key)   AS participants_count
FROM follow_up_service.users u
         JOIN follow_up_service.recordings r ON u.key = ANY (r.participants)
GROUP BY u.key, r.record_key, u.email, r.title, r.created_date, r.duration;

alter table user_participation
    owner to gen_user;

grant delete, insert, references, select, trigger, truncate, update on user_participation to admin;

