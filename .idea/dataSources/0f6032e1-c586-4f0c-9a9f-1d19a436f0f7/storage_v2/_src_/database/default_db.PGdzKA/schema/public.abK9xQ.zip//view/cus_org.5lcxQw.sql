create view cus_org
            (organization_id, organization_orders_left, is_count, customer_id, customer_type, username, phone_number,
             organization_name, count_applications, address)
as
SELECT organizations.organization_id,
       organizations.organization_orders_left,
       organizations.is_count,
       c.customer_id,
       c.customer_type,
       c.username,
       c.phone_number,
       c.organization_name,
       c.count_applications,
       c.address
FROM organizations
         LEFT JOIN customers c ON organizations.organization_id = c.organization_id;

alter table cus_org
    owner to gen_user;

grant delete, insert, references, select, trigger, truncate, update on cus_org to admin;

