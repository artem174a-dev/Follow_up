create view rent_info
            (organization_name, rent_id, courier_id, customer_id, status, courier_name, customer_name, point_a, point_b,
             price, comment, create_rent_time, start_time, end_time, rownumber)
as
WITH rankedrent AS (SELECT customers.organization_name,
                           rents.rent_id,
                           rents.courier_id,
                           rents.customer_id,
                           rent_details.status,
                           rent_details.courier_name,
                           rent_details.customer_name,
                           rent_details.point_a,
                           rent_details.point_b,
                           rent_details.price,
                           rent_details.comment,
                           rents.create_rent_time,
                           rent_details.start_time,
                           rent_details.end_time,
                           row_number()
                           OVER (PARTITION BY rents.rent_id ORDER BY rents.create_rent_time DESC) AS rownumber
                    FROM rents
                             JOIN customers ON rents.customer_id = customers.customer_id
                             LEFT JOIN rent_details ON rents.rent_id = rent_details.rent_id)
SELECT rankedrent.organization_name,
       rankedrent.rent_id,
       rankedrent.courier_id,
       rankedrent.customer_id,
       rankedrent.status,
       rankedrent.courier_name,
       rankedrent.customer_name,
       rankedrent.point_a,
       rankedrent.point_b,
       rankedrent.price,
       rankedrent.comment,
       rankedrent.create_rent_time,
       rankedrent.start_time,
       rankedrent.end_time,
       rankedrent.rownumber
FROM rankedrent
WHERE rankedrent.rownumber = 1
ORDER BY rankedrent.create_rent_time DESC;

alter table rent_info
    owner to gen_user;

grant delete, insert, references, select, trigger, truncate, update on rent_info to admin;

